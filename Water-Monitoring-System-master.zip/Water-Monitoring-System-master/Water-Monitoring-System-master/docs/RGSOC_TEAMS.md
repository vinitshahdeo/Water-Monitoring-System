|      Team Name     |     Member 1     | Member 2 |
|:-------------:|:-------------------:|:------------------:|
| Shooting Stars | Archie Tayal(@unique04) | micky-mouse2007(@micky-mouse2007)   |
|  mahadivya | Mahima Chauhan(@iammaximus) | P Divya Bharathi(@pdivyabharathi)   |
| oreos | bhavanavasireddy(@bhavanavasireddy) | pujithaasre(@pujithaasre)    |
| Pi | G Satya Sai Mownika(@Mownika25) | Sweta Jena(@swetajena98)    |
| SHANVI | Shreya Agarwal(@Shreya-495) | MANVI-15(@MANVI-15)    |
| that alpha thing | shubhi dua(@shubhidua) | ishitachauhan12(@ishitachauhan12)    |
| MichaelScode | Ishika Joshi(@sinchlairr) | sachleen11(@sachleen11)    |
| Codesh | Kesar Shrivastava(@kesar19051) | Vani Sikka(@08vani)    |
| Intellicode | Arya Jayadev K M(@aryajayadevkm) | Lakshmi Sunil(@Lakshmi-Sunil)    |
| MissingSemicolon | Muskan Goyal(@goyalmuskan) | Isha Singh(@Ishasingh04)    |
| GirlPower | shreya kapoor(@shreyakapoor08) | Siddhi Shree(@siddhishree)    |
| DumbAndDumbledore | Drishti Jain(@j-drishti) | Sakshi Saini(@SakshiSaini17092)    |
|  CodeAsia | Dhairya Chaudhary(@dhairyachaudhary) | Aairah Bari(@Aairah-iiitd)    |
| codingDuo | Sukriti Shah(@sukritishah15) | Samruddhi Nirali(@Samru123)    |
| Intentional nerds | waithiageni(@waithiageni) | Virginiah Periah Kengara (@virginiah894)    |
|  CodeInfinity | Manshi Todi(@todi-2000) | Pragati Verma(@PragatiVerma18)    |
|  error404 | Tawishi Sharma(@Tawishi) | Neeharika Taneja(@NeeharikaTaneja0299)    |
|  Alpha_Beta | Anjali Srivastava(@AnjaliSrivastava722) | Bhavya Arora(@Bhavya00)    |
|  Algoverts | Rudrakshi(@rudrakshi99) | Srashti Mittal(@Srashtimittal)    |
|  Callback Cats | marina saad(@marina-saad) | DoaaEssam52(@DoaaEssam52)    |
| techButterflies👩🏻‍💻🦋 | Akanksha Bhasin(@Akankshabhasin) | Archana Kumari(@archanaserver)    |
|  P.o.V. Persistence of Vision | Paloma Oliveira(@discombobulateme) | Victoria Hodder(@Victoria-Hodder)    |
| TheSmasshers | Akansha2202(@Akansha2202) | Monisha Ranjan(@scarlet2131)    |
| 200OK_SQQZ | Qian Zhao(@felicityzhao99) | 92612ShiyuQiu(@92612ShiyuQiu)   |
|  LogicWinners | Pritika Sabharwal(@PritikaSabharwal) | Nandini Agrawal(@nandiniagrawal2000)   |
| Null | Megha Varshney(@megha070) | kuja(@kuja24)   |
|  cdTech | Chhavi Kirtani(@chhavikirtani2000) | Deepi Garg(@deepigarg)   |